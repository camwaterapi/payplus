# Camwater PAY+ — Backend

FastAPI service for registration/login, meter linking, payments (Stripe/Flutterwave),
Top-Up Instructions (TUI), NFC sessions (card-only by default), and optional LUNA sync.
