# Camwater PAY+ — Android NFC Writer Bridge (skeleton)
Package: `com.camwater.payplus.nfcbridge`
Deep link: `camwaterpay://write?session=tui&tid=<id>&return=<url>`
