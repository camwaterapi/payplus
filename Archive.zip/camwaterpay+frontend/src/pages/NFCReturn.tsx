export default function NFCReturn(){
  return (<div className="mt-6 space-y-4"><h1 className="text-2xl font-bold">NFC write finished</h1>
    <div className="card">You can now present your card to the meter to load the credit.</div></div>)
}
